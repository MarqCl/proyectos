# Sistema-de-Ventas-CSharp-Visual-Studio-2013-SQL-Server-2012
Sistema de Ventas en 4 Capas desarrollado en Lenguaje C#, Módulos.

Sistema de ventas C#, 4 Capas. Visual Studio 2013, SQL Server 2012. Sistema de ventas - C#, 4 Capas. Visual Studio 2013, SQL Server 2012. 

Módulos: Ventas-Inventario-Compras-Empleados-Reportes-Login-Roles de usuarios.
