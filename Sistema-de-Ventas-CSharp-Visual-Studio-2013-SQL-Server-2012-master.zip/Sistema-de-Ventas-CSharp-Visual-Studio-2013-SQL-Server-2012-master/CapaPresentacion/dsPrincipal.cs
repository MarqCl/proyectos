﻿namespace CapaPresentacion {
    
    
    public partial class dsPrincipal {
        partial class spbuscar_ingreso_fechaDataTable
        {
        }
    }
}

namespace CapaPresentacion.dsPrincipalTableAdapters {
    
    
    public partial class spbuscar_ingreso_fechaTableAdapter {
    }
}
