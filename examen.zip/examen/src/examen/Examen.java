/*
 
 */

package examen;

import java.util.Scanner;
public class Examen {

    
    public static void main(String[] args) {
      


        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese la cantidad de elementos del arreglo: ");
        int cantidadElementos = sc.nextInt();
        int[] arreglo = new int[cantidadElementos];

        for (int i = 0; i < cantidadElementos; i++) {
            System.out.print("Ingrese el elemento " + (i + 1) + ": ");
            arreglo[i] = sc.nextInt();
        }

        int opcion;
        do {
            mostrarMenu();
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    sumarElementos(arreglo);
                    break;
                case 2:
                    sumarElementosCuadrado(arreglo);
                    break;
                case 3:
                    encontrarMenorElemento(arreglo);
                    break;
                case 4:
                    encontrarMayorElemento(arreglo);
                    break;
                case 5:
                    encontrarPosicionMenorMayor(arreglo);
                    break;
                case 6:
                    calcularPromedio(arreglo);
                    break;
                case 7:
                    ordenarAscendente(arreglo);
                    break;
                case 8:
                    ordenarDescendente(arreglo);
                    break;
                case 9:
                    contarNumerosPositivos(arreglo);
                    break;
                case 10:
                    contarCeros(arreglo);
                    break;
                case 11:
                    contarNumerosPrimos(arreglo);
                    break;
                case 12:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
                    break;
            }
            System.out.println();
        } while (opcion != 12);
        
        sc.close();
    }

    public static void mostrarMenu() {
        System.out.println("----- MENÚ DE OPCIONES -----");
        System.out.println("1. Sumar los elementos del arreglo");
        System.out.println("2. Sumar los elementos elevados al cuadrado");
        System.out.println("3. Determinar e imprimir el menor elemento del arreglo");
        System.out.println("4. Determinar e imprimir el mayor elemento del arreglo");
        System.out.println("5. Imprimir la posición del menor y mayor elemento del arreglo");
        System.out.println("6. Calcular el promedio de los elementos del arreglo");
        System.out.println("7. Ordenar los elementos en forma ascendente");
        System.out.println("8. Ordenar los elementos en forma descendente");
        System.out.println("9. Contar cuántos números positivos hay en el arreglo");
        System.out.println("10. Contar cuántos ceros hay en el arreglo");
        System.out.println("11. Contar cuántos números primos hay en el arreglo");
        System.out.println("12. Salir");
        System.out.print("Ingrese una opción: ");
    }

    public static void sumarElementos(int[] arreglo) {
        int suma = 0;
        for (int i = 0; i < arreglo.length; i++) {
            suma += arreglo[i];
        }
        System.out.println("La suma de los elementos del arreglo es: " + suma);
    }

    public static void sumarElementosCuadrado(int[] arreglo) {
        int sumaCuadrado = 0;
        for (int i = 0; i < arreglo.length; i++) {
            sumaCuadrado += arreglo[i] * arreglo[i];
        }
        System.out.println("La suma de los elementos elevados al cuadrado es: " + sumaCuadrado);
    }

    public static void encontrarMenorElemento(int[] arreglo) {
        int menor = arreglo[0];
        for (int i = 1; i < arreglo.length; i++) {
            if (arreglo[i] < menor) {
                menor = arreglo[i];
            }
        }
        System.out.println("El menor elemento del arreglo es: " + menor);
    }

    public static void encontrarMayorElemento(int[] arreglo) {
        int mayor = arreglo[0];
        for (int i = 1; i < arreglo.length; i++) {
            if (arreglo[i] > mayor) {
                mayor = arreglo[i];
            }
        }
        System.out.println("El mayor elemento del arreglo es: " + mayor);
    }

    public static void encontrarPosicionMenorMayor(int[] arreglo) {
        int menor = arreglo[0];
        int mayor = arreglo[0];
        int posicionMenor = 0;
        int posicionMayor = 0;
        for (int i = 1; i < arreglo.length; i++) {
            if (arreglo[i] < menor) {
                menor = arreglo[i];
                posicionMenor = i;
            }
            if (arreglo[i] > mayor) {
                mayor = arreglo[i];
                posicionMayor = i;
            }
        }
        System.out.println("El menor elemento se encuentra en la posición: " + posicionMenor);
        System.out.println("El mayor elemento se encuentra en la posición: " + posicionMayor);
    }

    public static void calcularPromedio(int[] arreglo) {
        int suma = 0;
        for (int i = 0; i < arreglo.length; i++) {
            suma += arreglo[i];
        }
        double promedio = (double) suma / arreglo.length;
        System.out.println("El promedio de los elementos del arreglo es: " + promedio);
    }

    public static void ordenarAscendente(int[] arreglo) {
        for (int i = 0; i < arreglo.length - 1; i++) {
            for (int j = 0; j < arreglo.length - i - 1; j++) {
                if (arreglo[j] > arreglo[j + 1]) {
                    int temp = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = temp;
                }
            }
        }
        System.out.println("El arreglo ordenado en forma ascendente es: ");
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print(arreglo[i] + " ");
        }
        System.out.println();
    }

   
                public static void ordenarDescendente(int[] arreglo) {
    for (int i = 0; i < arreglo.length - 1; i++) {
        for (int j = 0; j < arreglo.length - i - 1; j++) {
            if (arreglo[j] < arreglo[j + 1]) {
                int temp = arreglo[j];
                arreglo[j] = arreglo[j + 1];
                arreglo[j + 1] = temp;
            }
        }
    }
    System.out.println("El arreglo ordenado en forma descendente es: ");
    for (int i = 0; i < arreglo.length; i++) {
        System.out.print(arreglo[i] + " ");
    }
    System.out.println();
}

    public static void contarNumerosPositivos(int[] arreglo) {
        int contadorPositivos = 0;
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i] > 0) {
                contadorPositivos++;
            }
        }
        System.out.println("La cantidad de números positivos en el arreglo es: " + contadorPositivos);
    }

    public static void contarCeros(int[] arreglo) {
        int contadorCeros = 0;
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i] == 0) {
                contadorCeros++;
            }
        }
        System.out.println("La cantidad de ceros en el arreglo es: " + contadorCeros);
    }

    public static void contarNumerosPrimos(int[] arreglo) {
        int contadorPrimos = 0;
        for (int i = 0; i < arreglo.length; i++) {
            if (esPrimo(arreglo[i])) {
                contadorPrimos++;
            }
        }
        System.out.println("La cantidad de números primos en el arreglo es: " + contadorPrimos);
    }

    public static boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
}


    
    

